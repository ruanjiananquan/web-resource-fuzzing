<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>软件安全实践 · 课程资源中心</title>
<style>
  body{font-family:-apple-system,"Segoe UI",Roboto,"Microsoft YaHei",sans-serif;max-width:860px;margin:0 auto;padding:24px;color:#1f2937;line-height:1.7}
  h1{color:#0f4c81}
  h2{color:#0f4c81;border-bottom:2px solid #e5e7eb;padding-bottom:6px;margin-top:32px}
  .lead{color:#374151}
  .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:12px}
  .card{background:#f3f4f6;border-radius:8px;padding:14px}
  .card b{color:#0f4c81}
  footer{margin-top:40px;color:#6b7280;font-size:13px}
</style>
</head>
<body>
  <h1>软件安全实践 · 课程资源中心</h1>
  <p class="lead">欢迎来到本课程的学习资源站点。这里汇总了与课程相关的公开内容，供同学们日常查阅与自学。</p>

  <h2>站点内容导航</h2>
  <p>本资源中心围绕以下六个公开板块组织内容，便于快速定位所需资料：</p>
  <div class="grid">
    <div class="card"><b>Course</b><br>课程大纲与教学安排</div>
    <div class="card"><b>Materials</b><br>课件与阅读材料</div>
    <div class="card"><b>Downloads</b><br>工具与示例下载</div>
    <div class="card"><b>Notice</b><br>通知与公告</div>
    <div class="card"><b>Help</b><br>常见问题与帮助</div>
    <div class="card"><b>Contact</b><br>联系方式与答疑</div>
  </div>

  <h2>关于本课程</h2>
  <p>本课程面向信息安全方向研究生，覆盖 Web 应用安全、模糊测试、漏洞挖掘等主题。同学们可在上方六个板块中找到对应的公开资料。更多内容将在课堂与群里陆续发布。</p>

  <h2>友情提示</h2>
  <p>本站仅提供课程相关的公开学习资料。如对某板块有疑问，请通过帮助与联系方式板块获取支持。</p>

  <footer>软件安全实践课程组 · 课程资源中心（演示站点）</footer>
</body>
</html>
